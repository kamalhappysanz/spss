#
# TABLE STRUCTURE FOR: autonomous_exam
#

DROP TABLE IF EXISTS `autonomous_exam`;

CREATE TABLE `autonomous_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `file_upload` varchar(100) NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `autonomous_exam` (`id`, `title`, `file_upload`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (1, 'You Tube Channel 123333', '1573214602.jpg', 2, 'Active', 1, '2019-11-08 17:33:32');
INSERT INTO `autonomous_exam` (`id`, `title`, `file_upload`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (2, 'CanvasJS HTML5 JavaScript Charts', '1573214713.jpg', 3, 'Inactive', 1, '2019-11-08 17:35:12');
INSERT INTO `autonomous_exam` (`id`, `title`, `file_upload`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (3, '', '', 4, 'Active', 1, '2019-11-14 12:21:52');


#
# TABLE STRUCTURE FOR: banners
#

DROP TABLE IF EXISTS `banners`;

CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_title` varchar(100) NOT NULL,
  `banner_img` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `banners` (`id`, `banner_title`, `banner_img`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (3, 'Slider1', '1572866417.jpg', 'Active', '2019-11-04 16:49:50', 1, '2019-11-04 16:50:16', 1);


#
# TABLE STRUCTURE FOR: dept_activity
#

DROP TABLE IF EXISTS `dept_activity`;

CREATE TABLE `dept_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `association_name` varchar(100) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: dept_faculty
#

DROP TABLE IF EXISTS `dept_faculty`;

CREATE TABLE `dept_faculty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `desgination` varchar(50) NOT NULL,
  `faculty_position` int(11) NOT NULL,
  `degree` varchar(30) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `experience` varchar(30) NOT NULL,
  `faculty_email` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `dept_faculty` (`id`, `dept_id`, `faculty_name`, `desgination`, `faculty_position`, `degree`, `file_upload`, `experience`, `faculty_email`, `status`, `updated_at`, `updated_by`) VALUES (1, 1, 'Kamal Raj', '', 1, 'BE', '1573809252.jpg', '2.5', '0', 'Active', '2019-11-15 14:44:11', 1);
INSERT INTO `dept_faculty` (`id`, `dept_id`, `faculty_name`, `desgination`, `faculty_position`, `degree`, `file_upload`, `experience`, `faculty_email`, `status`, `updated_at`, `updated_by`) VALUES (2, 1, 'Kamal Raj', '', 2, 'BE', '1573809316.jpg', '1.5', 'kamal@kamal.com', 'Inactive', '2019-11-15 14:45:16', 1);
INSERT INTO `dept_faculty` (`id`, `dept_id`, `faculty_name`, `desgination`, `faculty_position`, `degree`, `file_upload`, `experience`, `faculty_email`, `status`, `updated_at`, `updated_by`) VALUES (3, 2, 'www', '', 2, 'wwww', '1573809459.jpg', '1.4', 'kamal@kamal.com', 'Inactive', '2019-11-15 14:47:38', 1);
INSERT INTO `dept_faculty` (`id`, `dept_id`, `faculty_name`, `desgination`, `faculty_position`, `degree`, `file_upload`, `experience`, `faculty_email`, `status`, `updated_at`, `updated_by`) VALUES (4, 2, 'Kamal Raj 123', 'HOD', 1, 'ME msc', '1573815155.jpg', '2.7', 'kamal@raj.com', 'Active', '2019-11-15 16:24:24', 1);


#
# TABLE STRUCTURE FOR: dept_lab_facility
#

DROP TABLE IF EXISTS `dept_lab_facility`;

CREATE TABLE `dept_lab_facility` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_name` varchar(100) NOT NULL,
  `lab_position` int(11) NOT NULL,
  `description` text NOT NULL,
  `lab_image` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `dept_lab_facility` (`id`, `lab_name`, `lab_position`, `description`, `lab_image`, `status`, `updated_at`, `updated_by`, `dept_id`) VALUES (1, 'mech lab', 1, '<p>description</p>', '1573820188.jpg', 'Active', '2019-11-15 17:46:28', 1, 3);


#
# TABLE STRUCTURE FOR: dept_syllabus
#

DROP TABLE IF EXISTS `dept_syllabus`;

CREATE TABLE `dept_syllabus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `syllabus_name` varchar(100) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: login_admin
#

DROP TABLE IF EXISTS `login_admin`;

CREATE TABLE `login_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `admin_type` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `profile_pic` varchar(50) NOT NULL,
  `id_proof` varchar(50) NOT NULL,
  `otp` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `login_admin` (`id`, `name`, `email`, `phone`, `username`, `password`, `admin_type`, `gender`, `address`, `city`, `qualification`, `profile_pic`, `id_proof`, `otp`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1, 'Kamal Raj', 'admin@citspc.in', '9789108819', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 1, 'Male', 'Coimbatore', '', '', '', '', 717026, 'Active', '0000-00-00 00:00:00', 0, '2019-11-04 16:51:38', 0);


#
# TABLE STRUCTURE FOR: tb_announcement
#

DROP TABLE IF EXISTS `tb_announcement`;

CREATE TABLE `tb_announcement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_departments
#

DROP TABLE IF EXISTS `tbl_departments`;

CREATE TABLE `tbl_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(100) NOT NULL,
  `dept_position` int(11) NOT NULL,
  `history` text NOT NULL,
  `vision` text NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (1, 'Mech', 2, '<p>Mech<br></p>', '<p>Mech<br></p>', '<p>Mech<br></p>', 'Inactive', '2019-11-14 14:12:38', 1);
INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (2, 'CSE', 4, '', '<p><span style=\"font-size: 15px; text-align: center; font-weight: normal;\">CSE</span><span style=\"font-size: 15px; text-align: center; font-family: \"Courier New\";\">?</span><br></p>', '<h6 style=\"text-align: center; \"><span style=\"font-weight: normal;\">CSE</span><span style=\"font-family: \"Courier New\";\">?</span></h6>', 'Active', '2019-11-14 16:50:00', 1);
INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (3, 'ssss', 1, '', '', '', 'Active', '2019-11-14 16:51:17', 1);
INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (4, 'dddd', 3, '', '', '', 'Active', '2019-11-14 16:52:10', 1);


