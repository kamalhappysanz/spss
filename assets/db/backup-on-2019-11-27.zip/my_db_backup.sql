#
# TABLE STRUCTURE FOR: autonomous_exam
#

DROP TABLE IF EXISTS `autonomous_exam`;

CREATE TABLE `autonomous_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `file_upload` varchar(100) NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `autonomous_exam` (`id`, `title`, `file_upload`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (1, 'You Tube Channel 123333', '1573214602.jpg', 2, 'Active', 1, '2019-11-08 17:33:32');
INSERT INTO `autonomous_exam` (`id`, `title`, `file_upload`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (2, 'CanvasJS HTML5 JavaScript Charts', '1573214713.jpg', 3, 'Inactive', 1, '2019-11-08 17:35:12');


#
# TABLE STRUCTURE FOR: banners
#

DROP TABLE IF EXISTS `banners`;

CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_title` varchar(100) NOT NULL,
  `banner_img` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `banners` (`id`, `banner_title`, `banner_img`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (3, 'Slider1', '1572866417.jpg', 'Active', '2019-11-04 16:49:50', 1, '2019-11-04 16:50:16', 1);


#
# TABLE STRUCTURE FOR: dept_faculty
#

DROP TABLE IF EXISTS `dept_faculty`;

CREATE TABLE `dept_faculty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `faculty_name` varchar(100) NOT NULL,
  `desgination` varchar(50) NOT NULL,
  `faculty_position` int(11) NOT NULL,
  `degree` varchar(30) NOT NULL,
  `profile_file` varchar(50) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `experience` varchar(30) NOT NULL,
  `faculty_email` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `dept_faculty` (`id`, `dept_id`, `faculty_name`, `desgination`, `faculty_position`, `degree`, `profile_file`, `file_upload`, `experience`, `faculty_email`, `status`, `updated_at`, `updated_by`) VALUES (1, 2, 'Kamal Raj', '1212', 2, '11', '1574854353.docx', '1574854353.jpg', '1111', 'kamal@kamal.com', 'Active', '2019-11-27 17:02:32', 1);
INSERT INTO `dept_faculty` (`id`, `dept_id`, `faculty_name`, `desgination`, `faculty_position`, `degree`, `profile_file`, `file_upload`, `experience`, `faculty_email`, `status`, `updated_at`, `updated_by`) VALUES (2, 2, 'Kamal Raj  12121', 'Principal', 1, 'wwww', '1574854604.docx', '1574854604.JPG', 'asd', 'kamal@kamal.com', 'Active', '2019-11-27 17:06:44', 1);


#
# TABLE STRUCTURE FOR: dept_lab_facility
#

DROP TABLE IF EXISTS `dept_lab_facility`;

CREATE TABLE `dept_lab_facility` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lab_name` varchar(100) NOT NULL,
  `lab_position` int(11) NOT NULL,
  `description` text NOT NULL,
  `lab_image` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `dept_lab_facility` (`id`, `lab_name`, `lab_position`, `description`, `lab_image`, `status`, `updated_at`, `updated_by`, `dept_id`) VALUES (1, 'mech lab', 1, '<p>description</p>', '1573820188.jpg', 'Active', '2019-11-15 17:46:28', 1, 3);
INSERT INTO `dept_lab_facility` (`id`, `lab_name`, `lab_position`, `description`, `lab_image`, `status`, `updated_at`, `updated_by`, `dept_id`) VALUES (2, 'Mech 2 aaaa', 2, '<p>aaaaaaaaaaaaaaa vvvvvvvvvvvvvvvvvvvv</p>', '1574007824.jpg', 'Active', '2019-11-17 21:56:28', 1, 3);
INSERT INTO `dept_lab_facility` (`id`, `lab_name`, `lab_position`, `description`, `lab_image`, `status`, `updated_at`, `updated_by`, `dept_id`) VALUES (3, 'DDDd', 2, '<p>dsfsdfd</p>', '1574057854.jpg', 'Active', '2019-11-18 11:47:33', 1, 4);
INSERT INTO `dept_lab_facility` (`id`, `lab_name`, `lab_position`, `description`, `lab_image`, `status`, `updated_at`, `updated_by`, `dept_id`) VALUES (4, 'dddd3333', 1, '<p>sfsdfsdf</p>', '1574057865.jpg', 'Active', '2019-11-18 11:47:44', 1, 4);


#
# TABLE STRUCTURE FOR: dept_syllabus_activity
#

DROP TABLE IF EXISTS `dept_syllabus_activity`;

CREATE TABLE `dept_syllabus_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) NOT NULL,
  `syllabus_association` varchar(15) NOT NULL,
  `ac_sy_name` varchar(100) NOT NULL,
  `file_name` varchar(50) NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (1, 2, 'Association', 'asss 21212121 aaa', '1574054174.jpg', 3, 'Inactive', 1, '2019-11-18 10:46:13');
INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (2, 2, 'Association', 'aaa', '1574054908.jpg', 2, 'Active', 1, '2019-11-18 10:58:27');
INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (3, 2, 'Association', 'QQQQ', '1574054967.jpg', 1, 'Active', 1, '2019-11-18 11:45:44');
INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (4, 2, 'Syllabus', 'sss', '1574055235.jpg', 1, 'Active', 1, '2019-11-18 11:03:54');
INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (5, 2, 'Syllabus', 'sssss12', '1574055255.jpg', 2, 'Active', 1, '2019-11-18 11:04:14');
INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (6, 4, 'Association', 'mech', '1574057775.jpg', 1, 'Active', 1, '2019-11-18 11:46:14');
INSERT INTO `dept_syllabus_activity` (`id`, `dept_id`, `syllabus_association`, `ac_sy_name`, `file_name`, `file_position`, `status`, `updated_by`, `updated_at`) VALUES (7, 4, 'Syllabus', 'mech sylla', '1574057822.jpg', 1, 'Active', 1, '2019-11-18 11:47:01');


#
# TABLE STRUCTURE FOR: login_admin
#

DROP TABLE IF EXISTS `login_admin`;

CREATE TABLE `login_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `admin_type` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `profile_pic` varchar(50) NOT NULL,
  `id_proof` varchar(50) NOT NULL,
  `otp` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `login_admin` (`id`, `name`, `email`, `phone`, `username`, `password`, `admin_type`, `gender`, `address`, `city`, `qualification`, `profile_pic`, `id_proof`, `otp`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1, 'Kamal Raj', 'admin@citspc.in', '9789108819', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 1, 'Male', 'Coimbatore', '', '', '', '', 717026, 'Active', '0000-00-00 00:00:00', 0, '2019-11-04 16:51:38', 0);


#
# TABLE STRUCTURE FOR: tb_announcement
#

DROP TABLE IF EXISTS `tb_announcement`;

CREATE TABLE `tb_announcement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `file_position` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_alumni
#

DROP TABLE IF EXISTS `tbl_alumni`;

CREATE TABLE `tbl_alumni` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course` varchar(50) NOT NULL,
  `year_of_passing` varchar(10) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `mobile_no` varchar(15) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_departments
#

DROP TABLE IF EXISTS `tbl_departments`;

CREATE TABLE `tbl_departments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(100) NOT NULL,
  `dept_position` int(11) NOT NULL,
  `history` text NOT NULL,
  `vision` text NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (1, 'Mech', 3, '<p>Mech<br></p>', '<p>Mech<br></p>', '<p>Mech<br></p>', 'Inactive', '2019-11-14 14:12:38', 1);
INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (2, 'CSE', 1, '', '<p><span style=\"font-size: 15px; text-align: center; font-weight: normal;\">CSE</span><span style=\"font-size: 15px; text-align: center; font-family: \"Courier New\";\">?</span><br></p>', '<h6 style=\"text-align: center; \"><span style=\"font-weight: normal;\">CSE</span><span style=\"font-family: \"Courier New\";\">?</span></h6>', 'Active', '2019-11-14 16:50:00', 1);
INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (3, 'ssss', 2, '', '', '', 'Active', '2019-11-14 16:51:17', 1);
INSERT INTO `tbl_departments` (`id`, `dept_name`, `dept_position`, `history`, `vision`, `description`, `status`, `updated_at`, `updated_by`) VALUES (4, 'dddd', 4, '', '', '', 'Active', '2019-11-14 16:52:10', 1);


#
# TABLE STRUCTURE FOR: tbl_general
#

DROP TABLE IF EXISTS `tbl_general`;

CREATE TABLE `tbl_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tbl_master_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `file_position` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (1, 1, 'sss', '1574158949.jpg', 2, '', 'Active', '2019-11-19 15:52:29', 1);
INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (2, 1, 'sss1', '1574158960.jpg', 1, '', 'Active', '2019-11-19 15:52:40', 1);
INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (3, 2, 'aaaa', '1574159144.jpg', 1, '', 'Active', '2019-11-19 15:55:44', 1);
INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (4, 2, 'aaaaaaaa', '1574159154.jpg', 2, '', 'Active', '2019-11-19 15:55:54', 1);
INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (5, 9, 'spic12444', '1574221655.jpg', 1, '', 'Active', '2019-11-20 09:19:10', 1);
INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (6, 9, 'spic12', '1574848342.jpg', 2, '', 'Active', '2019-11-27 15:22:21', 1);
INSERT INTO `tbl_general` (`id`, `tbl_master_id`, `title`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (7, 10, 'place ments', '1574848413.jpg', 1, '', 'Active', '2019-11-27 15:23:32', 1);


#
# TABLE STRUCTURE FOR: tbl_governing_council
#

DROP TABLE IF EXISTS `tbl_governing_council`;

CREATE TABLE `tbl_governing_council` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `desgination` varchar(100) NOT NULL,
  `file_upload` varchar(50) NOT NULL,
  `file_position` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_governing_council` (`id`, `name`, `desgination`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (1, 'Governor1222', 'Principal12121', '1574230145.jpg', 2, '<p>Addresss22222</p>', 'Inactive', '2019-11-20 11:39:04', 1);
INSERT INTO `tbl_governing_council` (`id`, `name`, `desgination`, `file_upload`, `file_position`, `description`, `status`, `updated_at`, `updated_by`) VALUES (2, 'CSE', 'Principal', '1574229422.jpg', 1, '<p>Princccc</p>', 'Active', '2019-11-20 11:27:02', 1);


#
# TABLE STRUCTURE FOR: tbl_masters
#

DROP TABLE IF EXISTS `tbl_masters`;

CREATE TABLE `tbl_masters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_name` varchar(100) NOT NULL,
  `status` varchar(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (1, 'Student Union', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (2, 'Downloads', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (3, 'Syllabi', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (4, 'Academic Calendar', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (5, 'Committee', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (6, 'Extra- Curricular Activities', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (7, 'Sports', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (8, 'CIICP Events', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (9, 'CIICP SPIC Members', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (10, 'Placement', 'Active', '0000-00-00 00:00:00', 0);
INSERT INTO `tbl_masters` (`id`, `module_name`, `status`, `updated_at`, `updated_by`) VALUES (11, 'SPIC members', 'Active', '0000-00-00 00:00:00', 0);


