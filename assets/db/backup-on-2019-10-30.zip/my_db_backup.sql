#
# TABLE STRUCTURE FOR: login_admin
#

DROP TABLE IF EXISTS `login_admin`;

CREATE TABLE `login_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `admin_type` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `qualification` varchar(30) NOT NULL,
  `profile_pic` varchar(50) NOT NULL,
  `id_proof` varchar(50) NOT NULL,
  `otp` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `login_admin` (`id`, `name`, `email`, `phone`, `username`, `password`, `admin_type`, `gender`, `address`, `city`, `qualification`, `profile_pic`, `id_proof`, `otp`, `status`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES (1, 'Kamal Raj', 'admin@skilex.com', '9789108819', 'admin', 'a827a53e38dc3a9c0db1bd44a3a80021', 1, 'Male', 'Chennai', '', '', '', '', 717026, 'Active', '0000-00-00 00:00:00', 0, '2019-10-23 10:00:10', 0);


